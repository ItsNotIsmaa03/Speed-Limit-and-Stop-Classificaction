# Ecuador Traffic Detection > 2024-12-14 7:44pm
https://universe.roboflow.com/proyectos-lyiyx/ecuador-traffic-detection

Provided by a Roboflow user
License: CC BY 4.0

